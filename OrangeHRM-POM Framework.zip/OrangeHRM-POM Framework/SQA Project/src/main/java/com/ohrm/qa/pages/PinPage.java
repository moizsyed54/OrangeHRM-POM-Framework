package com.ohrm.qa.pages;

import com.ohrm.qa.base.TestBase;

public class PinPage extends TestBase {
}
