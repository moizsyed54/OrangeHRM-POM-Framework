package com.ohrm.qa.util;

import com.ohrm.qa.base.TestBase;

public class TestUtil extends TestBase {
    public static long PAGE_LOAD_TIMEOUT=50;
    public static long IMPLICIT_WAIT =30;

}
